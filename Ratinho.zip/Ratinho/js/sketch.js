//declaração variáveis
var nuvem1, nuvem2;
var nuvem1Img, nuvem2Img;
var fimDeJogo, fimDeJogoImg;
var chao, chaoImg;
var chaoInvisivel;
var Ratinho;
var RatinhoImg;
var GrupoGato;
var GatoImg,Gato2Img,Gato3Img;
var Gato
var grupoNuvens;

//estado inicial para o jogo
var estadoJogo = "play";

//responsável por carregar todos os arquivos
function preload()
{
    RatinhoImg = loadAnimation("img/rato01.png", "img/rato02.png", "img/rato03.png");
    GatoImg = loadImage("img/gato.png");
    nuvem1Img = loadImage("img/nuvem.png");
    nuvem2Img = loadImage("img/nuvem2.png");
    fimDeJogoImg = loadImage("img/game-over.png");
    chaoImg = loadImage("img/ground2.png");
}

//função que inicializa o código
function setup()
{
  createCanvas(800,400);
    Ratinho = createSprite(10,10,10,10);
    Ratinho.addAnimation("Ratinho", RatinhoImg);
     Ratinho.scale = 0.1;
     Ratinho.x = 50;
    chao = createSprite(100,140,150,20);
    chao.addImage("chao", chaoImg);
    chaoInvisivel = createSprite(80, 155, 100, 20);
    chaoInvisivel.visible = false;
    fimDeJogo = createSprite(300,100,20,20);
    fimDeJogo.addImage(fimDeJogoImg);
    fimDeJogo.scale = 0.2;
    fimDeJogo.visible = false;
    GrupoGato = new Group();
    grupoNuvens = new Group();
}

//função que executa enquanto o código estiver funcionando
function draw()
{

    background("lightseagreen")

    if (estadoJogo==="play")
    {
    
        chao.velocityX = -2;
        if(chao.x<0)
        {
            chao.x = chao.width/2;
        } 

         if(keyDown("space"))
        {
       
            Ratinho.velocityY = -10;
        }

      
        Ratinho.velocityY = Ratinho.velocityY + 0.8;
        Ratinho.collide(chaoInvisivel);

        criaNuvens();
        criaGato();

        if(GrupoGato.isTouching(Ratinho)){
            estadoJogo = "end";
        }
    }

    else if(estadoJogo==="end")
    {
        
        chao.velocityX = 0;
        Ratinho.velocityY = 0;

        
        GrupoGato.setVelocityXEach(0);
        grupoNuvens.setVelocityXEach(0);

       
        fimDeJogo.visible = true;

      
        fill("black"); 
        text("Pressione espaço para reiniciar.", 220, 170);

        if(keyDown("space"))
        {
         estadoJogo = "play";
         GrupoGato.destroyEach();
         grupoNuvens.destroyEach(); 
        
         fimDeJogo.visible = false;
        }
    }

    drawSprites();
}

function criaNuvens()
{
    if(frameCount % 50 === 0)
    {
       var nuvem = createSprite(700,90,40,10);
       nuvem.velocityX = -2;

       var num = Math.round(random(1,2));
    
       switch(num){
        case 1: nuvem.addImage(nuvem1Img);
        break;
        case 2: nuvem.addImage(nuvem2Img);
        break;
        default: break;
       }

       
       nuvem.scale = 0.05;
       nuvem.y = Math.round(random(15,70));
     
       nuvem.lifetime = 500;
       
    
       grupoNuvens.add(nuvem);
    }
}

//criar a função dos cactos
function criaGato()
{
    if(frameCount % 50 === 0)
    {
       var Gato = createSprite(700,130,40,10);
       Gato.velocityX = -2;

      
       var num = Math.round(random(1,3));
    
       switch(num){
        case 1: Gato.addImage(GatoImg);
        break;
        case 2: Gato.addImage(GatoImg);
        break;
        case 3: Gato.addImage(GatoImg);
        break;
        default: break;
       }

       Gato.scale = 0.05;
       Gato.lifetime = 500;   
       GrupoGato.add(Gato);   
    }
}